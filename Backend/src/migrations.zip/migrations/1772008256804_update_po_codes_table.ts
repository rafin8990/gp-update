import pool from '../utils/dbClient';

export const name = '1772008256804_update_po_codes_table';

export const run = async () => {
  await pool.query(`
    ALTER TABLE po_codes
    ADD COLUMN IF NOT EXISTS lot_number BIGINT;
  `);
};