import pool from '../utils/dbClient';

export const name = '1771821709637_update_po_code_table';

export const run = async () => {
  await pool.query(`
    ALTER TABLE po_codes ADD COLUMN IF NOT EXISTS quantity BIGINT;
  `);
};